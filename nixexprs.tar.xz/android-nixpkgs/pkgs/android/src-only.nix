{ mkGeneric }:

mkGeneric {
  phases = [ "unpackPhase" ];
}
